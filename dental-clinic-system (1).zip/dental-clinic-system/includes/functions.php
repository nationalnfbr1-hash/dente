<?php

function require_login()
{
    if (empty($_SESSION['staff_id'])) {
        header('Location: ' . base_url('login.php'));
        exit;
    }
}

function current_staff()
{
    return [
        'id' => $_SESSION['staff_id'] ?? null,
        'name' => $_SESSION['staff_name'] ?? 'Guest',
        'role' => $_SESSION['staff_role'] ?? 'staff',
    ];
}

/** Only Manager (or Admin) can change treatment/service prices. Cashiers cannot. */
function can_manage_prices(): bool
{
    $role = strtolower($_SESSION['staff_role'] ?? '');
    return in_array($role, ['manager', 'admin'], true);
}

/** True for roles allowed to handle money (Billing, POS, Shifts): Manager + Cashier. Doctors don't. */
function can_handle_payments(): bool
{
    $role = strtolower($_SESSION['staff_role'] ?? '');
    return in_array($role, ['manager', 'admin', 'cashier'], true);
}

/** Blocks the page entirely for anyone who isn't allowed to handle money. */
function require_payment_access()
{
    if (!can_handle_payments()) {
        flash('error', 'Only Manager or Cashier accounts can access Billing/POS.');
        redirect('index.php');
    }
}

/** Blocks the page/action entirely for anyone who isn't Manager/Admin. */
function require_manager()
{
    if (!can_manage_prices()) {
        flash('error', 'Only a Manager can do that.');
        redirect('index.php');
    }
}

/** Manager AND Cashier can manage appointments (book/confirm/cancel/reschedule). Doctors are view-only. */
function can_manage_appointments(): bool
{
    $role = strtolower($_SESSION['staff_role'] ?? '');
    return in_array($role, ['manager', 'admin', 'cashier', 'receptionist'], true);
}

function require_appointment_access()
{
    if (!can_manage_appointments()) {
        flash('error', 'You do not have permission to manage appointments.');
        redirect('appointments/index.php');
    }
}

/** Reads clinic-wide settings (name, currency) from the DB, cached per-request. */
function clinic_settings(): array
{
    static $cached = null;
    if ($cached !== null) return $cached;
    $row = Supabase::selectOne('clinic_settings', ['id' => 'eq.1']);
    $cached = [
        'clinic_name' => $row['clinic_name'] ?? APP_NAME,
        'currency_symbol' => $row['currency_symbol'] ?? APP_CURRENCY,
        'currency_code' => $row['currency_code'] ?? 'USD',
        'secondary_currency_name' => $row['secondary_currency_name'] ?? null,
        'secondary_currency_code' => $row['secondary_currency_code'] ?? null,
        'exchange_rate' => $row['exchange_rate'] ?? null,
        'logo_url' => $row['logo_url'] ?? null,
    ];
    return $cached;
}

/** Returns the current staff member's OPEN shift row, or null if none is open. */
function get_open_shift(): ?array
{
    static $cached = 'unset';
    if ($cached !== 'unset') return $cached;
    $staffId = current_staff()['id'];
    $cached = Supabase::selectOne('cashier_shifts', [
        'cashier_id' => 'eq.' . $staffId,
        'status' => 'eq.open',
    ]);
    return $cached;
}

/** Blocks POS sales if the current staff member has no open shift. */
function require_open_shift(): void
{
    if (!get_open_shift()) {
        flash('error', 'Please open a shift before making a sale.');
        redirect('pos/shift.php');
    }
}

function is_doctor(): bool
{
    $role = strtolower($_SESSION['staff_role'] ?? '');
    return in_array($role, ['doctor', 'dentist'], true);
}

/** Returns the current doctor's open (not checked-out) attendance row, or null. */
function get_open_attendance()
{
    static $cached = 'unset';
    if ($cached !== 'unset') return $cached;
    $cached = Supabase::selectOne('doctor_attendance', [
        'doctor_id' => 'eq.' . current_staff()['id'],
        'status' => 'eq.in',
    ]);
    return $cached;
}

/** Works out the app's base URL so links work whatever subfolder it's installed in. */
function base_url(string $path = ''): string
{
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    $root = rtrim(str_replace('\\', '/', dirname($script)), '/');
    // walk up out of module folders (patients/, billing/, etc.) to the app root
    $known = ['patients', 'dental-chart', 'appointments', 'treatments', 'billing', 'pharmacy', 'staff', 'expenses', 'pos', 'settings', 'backup', 'shifts', 'attendance', 'prescriptions', 'lab'];
    foreach ($known as $folder) {
        if (str_ends_with($root, '/' . $folder)) {
            $root = substr($root, 0, -strlen('/' . $folder));
        }
    }
    return $root . '/' . ltrim($path, '/');
}

function asset(string $path): string
{
    return base_url('assets/' . ltrim($path, '/'));
}

function flash(string $key, string $message = null)
{
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function money($amount): string
{
    return clinic_settings()['currency_symbol'] . number_format((float)$amount, 2);
}

/** Returns the same amount converted to the secondary currency, formatted, or '' if not configured. */
function money_secondary($amount): string
{
    $s = clinic_settings();
    if (empty($s['exchange_rate']) || empty($s['secondary_currency_code'])) return '';
    $converted = (float)$amount * (float)$s['exchange_rate'];
    return number_format($converted, 2) . ' ' . $s['secondary_currency_code'];
}

function h($str): string
{
    return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8');
}

function generate_patient_code(): string
{
    $n = Supabase::rpc('get_next_number', ['counter_id' => 'patient']);
    if ($n === false || $n === null) { return 'PT-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)); } // fallback
    return 'PT-' . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}

function generate_invoice_no(): string
{
    $n = Supabase::rpc('get_next_number', ['counter_id' => 'invoice']);
    if ($n === false || $n === null) { return 'INV-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(2)), 0, 4)); } // fallback
    return 'INV-' . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}

function generate_pos_sale_no(): string
{
    $n = Supabase::rpc('get_next_number', ['counter_id' => 'pos_sale']);
    if ($n === false || $n === null) { return 'POS-' . date('Ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(2)), 0, 4)); } // fallback
    return 'POS-' . str_pad((string)$n, 5, '0', STR_PAD_LEFT);
}

function redirect(string $path)
{
    header('Location: ' . base_url($path));
    exit;
}

const TOOTH_CONDITIONS = [
    'healthy' => 'Healthy',
    'cavity' => 'Cavity',
    'filling' => 'Filling',
    'extraction' => 'Extraction',
    'crown' => 'Crown',
    'root_canal' => 'Root Canal',
    'missing' => 'Missing Tooth',
];

const TREATMENT_STATUSES = [
    'none' => 'None',
    'planned' => 'Planned',
    'in_progress' => 'In Progress',
    'completed' => 'Completed',
];

const PAYMENT_METHODS = [
    'cash' => 'Cash',
    'card' => 'Card',
    'zaad' => 'ZAAD',
    'edahab' => 'eDahab',
    'premier' => 'Premier Wallet',
];

function payment_method_label(string $method): string
{
    return PAYMENT_METHODS[$method] ?? ucfirst(str_replace('_', ' ', $method));
}
