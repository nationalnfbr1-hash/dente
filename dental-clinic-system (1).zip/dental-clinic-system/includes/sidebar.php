<?php
$current = basename($_SERVER['SCRIPT_NAME']);
$dir = basename(dirname($_SERVER['SCRIPT_NAME']));
function nav_active($folder, $dir) { return $dir === $folder ? 'active' : ''; }
$isManager = can_manage_prices(); // true for manager/admin roles
?>
<div class="sidebar">
  <div class="brand" style="display:flex;align-items:flex-start;justify-content:space-between;gap:8px;">
    <span style="display:flex;align-items:center;gap:8px;">
      <?php if (!empty(clinic_settings()['logo_url'])): ?>
        <img src="<?= h(clinic_settings()['logo_url']) ?>" alt="Logo" style="height:26px;width:26px;object-fit:contain;border-radius:6px;background:#fff;">
      <?php else: ?>🦷<?php endif; ?>
      <span>
        <?= h(clinic_settings()['clinic_name']) ?>
        <small style="display:block;">Clinic Management</small>
      </span>
    </span>
    <button type="button" class="sidebar-close-btn" onclick="toggleSidebar(false)" aria-label="Close menu">✕</button>
  </div>
  <nav>
    <div class="section-label">Overview</div>
    <a class="<?= $current === 'index.php' && $dir !== 'patients' ? (in_array($dir,['patients','dental-chart','appointments','treatments','billing','pharmacy']) ? '' : 'active') : '' ?>" href="<?= base_url('index.php') ?>">📊 Dashboard</a>

    <div class="section-label">Clinical</div>
    <a class="<?= nav_active('patients', $dir) ?>" href="<?= base_url('patients/index.php') ?>">🧑‍⚕️ Patients</a>
    <a class="<?= nav_active('dental-chart', $dir) ?>" href="<?= base_url('dental-chart/index.php') ?>">🦷 Dental Chart</a>
    <a class="<?= nav_active('appointments', $dir) ?>" href="<?= base_url('appointments/index.php') ?>">📅 Appointments</a>
    <a class="<?= nav_active('attendance', $dir) ?>" href="<?= base_url('attendance/index.php') ?>">🕘 My Attendance</a>
    <a class="<?= nav_active('treatments', $dir) ?>" href="<?= base_url('treatments/index.php') ?>">🩺 Treatments</a>
    <a class="<?= nav_active('prescriptions', $dir) ?>" href="<?= base_url('prescriptions/index.php') ?>">💊 Prescriptions</a>
    <a class="<?= nav_active('lab', $dir) ?>" href="<?= base_url('lab/index.php') ?>">🦷 Lab Orders</a>

    <div class="section-label">Finance</div>
    <?php if (can_handle_payments()): ?>
    <a class="<?= nav_active('pos', $dir) ?>" href="<?= base_url('pos/index.php') ?>">🧾 POS / Make Sale</a>
    <a href="<?= base_url('pos/shift.php') ?>">🕒 Cashier Shift</a>
    <a class="<?= nav_active('billing', $dir) ?>" href="<?= base_url('billing/index.php') ?>">💳 Billing &amp; Payments</a>
    <a href="<?= base_url('billing/report.php') ?>"><?= $isManager ? '📈 Report' : '📈 My Sales' ?></a>
    <?php endif; ?>
    <?php if ($isManager): ?>
    <a href="<?= base_url('expenses/index.php') ?>">💸 Expenses</a>
    <?php endif; ?>

    <div class="section-label">Stock</div>
    <a class="<?= nav_active('pharmacy', $dir) ?>" href="<?= base_url('pharmacy/index.php') ?>">💊 Pharmacy / Inventory</a>

    <?php if ($isManager): ?>
    <div class="section-label">Admin</div>
    <a class="<?= nav_active('staff', $dir) ?>" href="<?= base_url('staff/index.php') ?>">👤 Manage Staff</a>
    <a class="<?= nav_active('shifts', $dir) ?>" href="<?= base_url('shifts/index.php') ?>">🕒 All Shifts</a>
    <a class="<?= nav_active('settings', $dir) ?>" href="<?= base_url('settings/index.php') ?>">⚙️ Manage Settings</a>
    <a class="<?= nav_active('backup', $dir) ?>" href="<?= base_url('backup/index.php') ?>">🗄️ Backup / Database</a>
    <?php endif; ?>
  </nav>
</div>
