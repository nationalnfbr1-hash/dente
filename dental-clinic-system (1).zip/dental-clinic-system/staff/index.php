<?php
require_once __DIR__ . '/../config/config.php';
require_manager();
$page_title = 'Manage Staff';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'create') {
    $hash = password_hash($_POST['password'], PASSWORD_BCRYPT);
    Supabase::insert('staff', [
        'full_name' => trim($_POST['full_name']),
        'username' => trim($_POST['username']),
        'password_hash' => $hash,
        'role' => $_POST['role'],
        'phone' => trim($_POST['phone']),
        'active' => true,
    ]);
    flash('success', 'Staff account created.');
    redirect('staff/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'toggle') {
    $s = Supabase::selectOne('staff', ['id' => 'eq.' . $_POST['id']]);
    Supabase::update('staff', ['id' => 'eq.' . $_POST['id']], ['active' => !$s['active']]);
    redirect('staff/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'reset_password') {
    $hash = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
    Supabase::update('staff', ['id' => 'eq.' . $_POST['id']], ['password_hash' => $hash]);
    flash('success', 'Password reset.');
    redirect('staff/index.php');
}

$staffList = Supabase::select('staff', ['order' => 'created_at.asc']);

require __DIR__ . '/../includes/header.php';
?>

<div class="section-title">👤 Manage Staff (Manager only)</div>

<table class="data">
  <tr><th>Name</th><th>Username</th><th>Role</th><th>Phone</th><th>Status</th><th></th></tr>
  <?php foreach ($staffList as $s): ?>
    <tr>
      <td><?= h($s['full_name']) ?></td>
      <td><?= h($s['username']) ?></td>
      <td><span class="badge teal"><?= h(ucfirst($s['role'])) ?></span></td>
      <td><?= h($s['phone']) ?: '—' ?></td>
      <td><?= $s['active'] ? '<span class="badge green">Active</span>' : '<span class="badge red">Disabled</span>' ?></td>
      <td style="white-space:nowrap;">
        <form method="post" style="display:inline;">
          <input type="hidden" name="form" value="toggle">
          <input type="hidden" name="id" value="<?= h($s['id']) ?>">
          <button class="btn small outline" onclick="return confirm('<?= $s['active'] ? 'Disable' : 'Enable' ?> this account?')"><?= $s['active'] ? 'Disable' : 'Enable' ?></button>
        </form>
        <button class="btn small outline" onclick="document.getElementById('reset-<?= h($s['id']) ?>').style.display='flex'">Reset password</button>
      </td>
    </tr>
    <tr id="reset-<?= h($s['id']) ?>" style="display:none;">
      <td colspan="6">
        <form method="post" style="display:flex;gap:8px;align-items:end;">
          <input type="hidden" name="form" value="reset_password">
          <input type="hidden" name="id" value="<?= h($s['id']) ?>">
          <div><label>New password for <?= h($s['username']) ?></label><input type="text" name="new_password" required></div>
          <button class="btn small">Save new password</button>
        </form>
      </td>
    </tr>
  <?php endforeach; ?>
</table>

<div class="section-title" style="margin-top:26px;">+ Create new staff account</div>
<form method="post" class="card form-grid">
  <input type="hidden" name="form" value="create">
  <div>
    <label>Full name *</label>
    <input type="text" name="full_name" required>
  </div>
  <div>
    <label>Phone</label>
    <input type="text" name="phone">
  </div>
  <div>
    <label>Username *</label>
    <input type="text" name="username" required>
  </div>
  <div>
    <label>Password *</label>
    <input type="text" name="password" required>
  </div>
  <div>
    <label>Role *</label>
    <select name="role" required>
      <option value="cashier">Cashier</option>
      <option value="doctor">Doctor</option>
      <option value="dentist">Dentist</option>
      <option value="receptionist">Receptionist</option>
      <option value="dental_assistant">Dental Assistant</option>
      <option value="lab_technician">Lab Technician</option>
      <option value="manager">Manager</option>
    </select>
  </div>
  <div class="full">
    <button class="btn">Create account</button>
  </div>
</form>

<?php require __DIR__ . '/../includes/footer.php'; ?>
