<?php
require_once __DIR__ . '/../config/config.php';
require_manager();
$page_title = 'Settings';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $update = [
        'clinic_name' => trim($_POST['clinic_name']),
        'currency_symbol' => trim($_POST['currency_symbol']),
        'currency_code' => trim($_POST['currency_code']),
        'secondary_currency_name' => trim($_POST['secondary_currency_name']),
        'secondary_currency_code' => trim($_POST['secondary_currency_code']),
        'exchange_rate' => $_POST['exchange_rate'] !== '' ? (float)$_POST['exchange_rate'] : null,
        'updated_at' => date('c'),
    ];

    // handle logo upload (optional)
    if (!empty($_FILES['logo']['name']) && $_FILES['logo']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = __DIR__ . '/../uploads/logo/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $safeName = 'logo_' . time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $_FILES['logo']['name']);
        move_uploaded_file($_FILES['logo']['tmp_name'], $uploadDir . $safeName);
        $update['logo_url'] = base_url('uploads/logo/' . $safeName);
    }

    Supabase::update('clinic_settings', ['id' => 'eq.1'], $update);
    flash('success', 'Settings saved.');
    redirect('settings/index.php');
}

$settings = clinic_settings();

require __DIR__ . '/../includes/header.php';
?>

<div class="section-title">⚙️ Manage Settings (Manager only)</div>

<form method="post" class="card form-grid" enctype="multipart/form-data">
  <div>
    <label>Clinic name</label>
    <input type="text" name="clinic_name" value="<?= h($settings['clinic_name']) ?>" required>
  </div>
  <div class="full">
    <label>Clinic logo</label>
    <?php if (!empty($settings['logo_url'])): ?>
      <div style="margin-bottom:10px;">
        <img src="<?= h($settings['logo_url']) ?>" alt="Current logo" style="max-height:70px;border:1px solid var(--line);border-radius:8px;padding:6px;">
      </div>
    <?php endif; ?>
    <input type="file" name="logo" accept="image/*">
    <p style="color:var(--slate);font-size:12.5px;margin-top:6px;">Upload a PNG or JPG. Leave empty to keep the current logo.</p>
  </div>
  <div class="full"><h3 style="margin-top:10px;">Currency Settings</h3></div>
  <div>
    <label>Currency Symbol</label>
    <input type="text" name="currency_symbol" value="<?= h($settings['currency_symbol']) ?>" required>
  </div>
  <div>
    <label>Currency Code</label>
    <input type="text" name="currency_code" value="<?= h($settings['currency_code']) ?>" placeholder="USD">
  </div>
  <div>
    <label>Secondary Currency</label>
    <input type="text" name="secondary_currency_name" value="<?= h($settings['secondary_currency_name']) ?>" placeholder="Somali Shilling">
  </div>
  <div>
    <label>Secondary Currency Code</label>
    <input type="text" name="secondary_currency_code" value="<?= h($settings['secondary_currency_code']) ?>" placeholder="SOS">
  </div>
  <div class="full">
    <label>Exchange Rate</label>
    <input type="number" step="0.0001" name="exchange_rate" value="<?= h($settings['exchange_rate']) ?>" placeholder="569.21">
    <?php if (!empty($settings['exchange_rate']) && !empty($settings['currency_code']) && !empty($settings['secondary_currency_code'])): ?>
      <p style="color:var(--slate);font-size:13px;margin-top:6px;">
        1 <?= h($settings['currency_code']) ?> = <?= h(number_format($settings['exchange_rate'], 2)) ?> <?= h($settings['secondary_currency_code']) ?>
      </p>
    <?php endif; ?>
  </div>
  <div class="full">
    <button class="btn">Save Settings</button>
  </div>
</form>

<div class="section-title" style="margin-top:26px;">Supabase connection</div>
<div class="card" style="color:var(--slate);">
  <p><strong>Project URL:</strong> <?= h(SUPABASE_URL) ?></p>
  <p>To change the Supabase project or API key, edit <code>config/config.php</code> directly on the server.</p>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
