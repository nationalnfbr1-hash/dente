# Smile Care — Dental Clinic Management System

PHP + Supabase (Postgres via REST/PostgREST) admin system covering:
Dashboard, Patients, Dental Chart (32 teeth), Appointments, Treatments/Services,
Billing & Payments, and Pharmacy/Inventory.

## 1. Create the Supabase database

1. Go to your Supabase project → **SQL Editor** → New query.
2. Paste the contents of `supabase/schema.sql` and run it.
   This creates all tables (patients, dental_chart, appointments, services,
   treatments, invoices, payments, inventory_items, inventory_movements,
   staff) and enables Row Level Security with an open policy for the
   `anon` role — safe here because Supabase is only ever called from this
   PHP backend, never directly from a browser.

## 2. Configure the app

Open `config/config.php` and set:

```php
define('SUPABASE_URL', 'https://YOUR-PROJECT-REF.supabase.co');
define('SUPABASE_KEY', 'sb_publishable_mQ7iI6D0dXTgtC92ZJ3xow_Qz2iOTRr');
```

Replace `SUPABASE_URL` with your actual Project URL (Project Settings → API).
The publishable key you gave me is already wired in.

> **Security note:** the publishable/anon key is meant for browsers, but here
> it's used only from PHP running on your server, so it's never exposed to
> visitors. For a stricter setup later, switch to the **service_role** key
> (Project Settings → API) in `SUPABASE_KEY`, and tighten the RLS policies
> in `schema.sql` to deny `anon` entirely — the service role bypasses RLS.

## 3. Create your first login

From the server, run once:

```bash
php setup/create_admin.php
```

It will ask for a name, username and password, and create a `staff` row
with a properly hashed password. Then log in at `login.php`.

## 4. Point your webserver at the project root

Any PHP 8+ with `curl` extension enabled works — Apache, Nginx+PHP-FPM, or
just for local testing:

```bash
php -S localhost:8000
```

Then open `http://localhost:8000/login.php`.

## Folder guide

```
config/config.php        Supabase URL/key + app settings
includes/                Supabase REST client, header/sidebar/footer, helpers
supabase/schema.sql       Full database schema + RLS policies
setup/create_admin.php    One-time CLI script to create a login
index.php                 Dashboard
patients/                 Patient management (profile, history, x-rays/docs)
dental-chart/             Interactive 32-tooth chart per patient
appointments/             Booking, reschedule/cancel, reminders
treatments/               Service price list + treatment log
billing/                  Invoices, payments, printable receipt
pharmacy/                 Inventory + stock in/out log (only Manager can add/edit items)
staff/                    Manage Staff — create Cashier/Dentist/Manager accounts, reset passwords (Manager only)
expenses/                 Record and review clinic expenses (Manager only)
uploads/                  Patient x-rays/documents land here (created on first upload)
```

## Roles

- **Manager** (roles `manager` or `admin`): full access — can add/edit service prices, add/edit inventory items, manage staff accounts, view the full sales Report, and record Expenses.
- **Cashier** (or any other role): can take payments (Billing), search/view stock and record stock in/out, and only sees their *own* collected payments under "My Sales". They cannot change prices, add inventory items, manage staff, or see Expenses.

To add a new Cashier (or any staff) account, log in as a Manager and go to **Manage Staff** in the sidebar — no more manual SQL needed for this.

## Notes on things you'll likely want to extend

- **WhatsApp/SMS reminders**: `appointments/index.php` has a `send_reminder()`
  stub. Wire in your provider (Twilio, WhatsApp Cloud API, etc.) using the
  `WHATSAPP_API_URL` / `WHATSAPP_API_TOKEN` constants in `config/config.php`.
- **File storage**: patient x-rays/documents currently save to a local
  `uploads/` folder on the PHP server, with only the metadata (name, URL)
  stored in Supabase. For a multi-server or cloud setup, swap this for
  Supabase Storage (`/storage/v1/object/...`) using the same REST pattern
  already used in `includes/supabase_client.php`.
- **Roles/permissions**: `staff.role` (admin/dentist/receptionist) is stored
  but not yet used to restrict pages — add checks in `functions.php` if you
  need per-role page access.
