<?php
/**
 * Central configuration.
 *
 * IMPORTANT ABOUT THE KEY BELOW
 * ------------------------------------------------------------------
 * `sb_publishable_...` is Supabase's new "publishable" (anon) key.
 * It is safe to ship to a browser, but it only works through
 * PostgREST if you enable Row Level Security policies that allow
 * the `anon` role to act (the schema.sql included in /supabase does
 * this for you, since this whole app is only reachable through the
 * PHP admin panel — never call Supabase directly from JS with this
 * key in this project).
 *
 * For a production clinic system, create a SERVICE ROLE key in
 * Supabase (Project Settings -> API) and put it in SUPABASE_KEY
 * instead, then tighten the RLS policies in schema.sql so that only
 * the service role can write. The service role key must NEVER be
 * sent to the browser — only used here, server-side, in PHP.
 */

// ---- Supabase project settings -----------------------------------
define('SUPABASE_URL', 'https://gmnhsztcgsmjfuoumiud.supabase.co');
define('SUPABASE_KEY', 'sb_publishable_mQ7iI6D0dXTgtC92ZJ3xow_Qz2iOTRr'); // anon/publishable key

// ---- App settings ---------------------------------------------------
define('APP_NAME', 'Smile Care Dental Clinic');
define('APP_TIMEZONE', 'Africa/Mogadishu');
define('APP_CURRENCY', '$');

// ---- Twilio / WhatsApp (optional, for reminders) ---------------------
define('WHATSAPP_ENABLED', false);
define('WHATSAPP_API_URL', '');   // e.g. your WhatsApp Cloud API endpoint
define('WHATSAPP_API_TOKEN', '');

date_default_timezone_set(APP_TIMEZONE);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

error_reporting(E_ALL);
ini_set('display_errors', '1');

require_once __DIR__ . '/../includes/supabase_client.php';
require_once __DIR__ . '/../includes/functions.php';
